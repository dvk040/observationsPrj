$(function(){
	$('#slides1').bxSlider({
		prev_image: 'images/btn_arrow_left.jpg',
		next_image: 'images/btn_arrow_right.jpg',
		wrapper_class: 'slides1_wrap',
		margin: 70,
		auto: true,
		auto_controls: true
	});
});