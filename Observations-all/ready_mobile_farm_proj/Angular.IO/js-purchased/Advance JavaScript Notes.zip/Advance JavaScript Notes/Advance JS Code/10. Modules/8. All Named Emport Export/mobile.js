// All Named Export
class Nokia {
  VolumnUp() {
    console.log("High Volumn");
  }
}

function show() {
  console.log("Hello Module");
}

export const a = 10;

export { Nokia, show };
