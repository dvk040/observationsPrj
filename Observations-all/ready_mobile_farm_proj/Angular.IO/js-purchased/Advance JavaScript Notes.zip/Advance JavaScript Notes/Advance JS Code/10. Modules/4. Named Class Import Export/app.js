// Named Import Class
import { Nokia } from "./mobile.js";
const n = new Nokia();
n.VolumnUp();
